EjemploFragmentClass
====================

En este ejemplo se lleva a cabo la realización de un Fragment.
En modo Portrait cuando se pulsa un elemento del ListView, se muetra la información en una nueva actividad.
En modo Landscape cuando se pulsa un elemento del ListView, se muestra la información en la zona detalle a la derecha del ListView.

http://desarrollandoandroid.wordpress.com

desarrollando.android2014@gmail.com

Creado por: Pablo Bascuñana Saiz.
